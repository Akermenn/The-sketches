PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS trade_status_history;
DROP TABLE IF EXISTS trades;
DROP TABLE IF EXISTS portfolio_positions;
DROP TABLE IF EXISTS market_prices;
DROP TABLE IF EXISTS instruments;
DROP TABLE IF EXISTS instrument_types;
DROP TABLE IF EXISTS currencies;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  user_id     INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name   TEXT NOT NULL,
  email       TEXT NOT NULL UNIQUE,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE instrument_types (
  type_id INTEGER PRIMARY KEY AUTOINCREMENT,
  code    TEXT NOT NULL UNIQUE,
  name    TEXT NOT NULL
);

CREATE TABLE currencies (
  currency_code TEXT PRIMARY KEY,
  name          TEXT NOT NULL
);

CREATE TABLE instruments (
  instrument_id  INTEGER PRIMARY KEY AUTOINCREMENT,
  type_id        INTEGER NOT NULL,
  ticker         TEXT NOT NULL UNIQUE,
  name           TEXT NOT NULL,
  currency_code  TEXT NOT NULL,
  FOREIGN KEY (type_id) REFERENCES instrument_types(type_id),
  FOREIGN KEY (currency_code) REFERENCES currencies(currency_code)
);

CREATE TABLE market_prices (
  price_id       INTEGER PRIMARY KEY AUTOINCREMENT,
  instrument_id  INTEGER NOT NULL,
  as_of_ts       TEXT NOT NULL,
  price          REAL NOT NULL,
  currency_code  TEXT NOT NULL,
  FOREIGN KEY (instrument_id) REFERENCES instruments(instrument_id),
  FOREIGN KEY (currency_code) REFERENCES currencies(currency_code)
);

CREATE TABLE portfolio_positions (
  position_id    INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id        INTEGER NOT NULL,
  instrument_id  INTEGER NOT NULL,
  quantity       REAL NOT NULL CHECK (quantity >= 0),
  avg_price      REAL,
  currency_code  TEXT NOT NULL,
  updated_at     TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(user_id, instrument_id),
  FOREIGN KEY (user_id) REFERENCES users(user_id),
  FOREIGN KEY (instrument_id) REFERENCES instruments(instrument_id),
  FOREIGN KEY (currency_code) REFERENCES currencies(currency_code)
);

CREATE TABLE trades (
  trade_id       INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id        INTEGER NOT NULL,
  instrument_id  INTEGER NOT NULL,
  side           TEXT NOT NULL CHECK (side IN ('BUY','SELL')),
  qty            REAL NOT NULL CHECK (qty > 0),
  price          REAL NOT NULL,
  currency_code  TEXT NOT NULL,
  status         TEXT NOT NULL CHECK (status IN ('EXECUTED','CANCELED')),
  executed_at    TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(user_id),
  FOREIGN KEY (instrument_id) REFERENCES instruments(instrument_id),
  FOREIGN KEY (currency_code) REFERENCES currencies(currency_code)
);

CREATE TABLE trade_status_history (
  hist_id    INTEGER PRIMARY KEY AUTOINCREMENT,
  trade_id   INTEGER NOT NULL,
  status     TEXT NOT NULL,
  changed_at TEXT NOT NULL DEFAULT (datetime('now')),
  comment    TEXT,
  FOREIGN KEY (trade_id) REFERENCES trades(trade_id)
);

INSERT INTO currencies(currency_code, name) VALUES
('RUB','Russian Ruble'),
('USD','US Dollar');

INSERT INTO instrument_types(code, name) VALUES
('STOCK','Акция'),
('BOND','Облигация'),
('FUND','Фонд');

INSERT INTO users(full_name, email) VALUES
('Иван Петров','ivan.petrov@example.com');

INSERT INTO instruments(type_id, ticker, name, currency_code) VALUES
((SELECT type_id FROM instrument_types WHERE code='STOCK'), 'YNDX', 'Яндекс', 'RUB'),
((SELECT type_id FROM instrument_types WHERE code='FUND'),  'SBSP', 'S&P 500 ETF', 'USD');

INSERT INTO market_prices(instrument_id, as_of_ts, price, currency_code) VALUES
(1, datetime('now','-1 hour'), 3000, 'RUB'),
(2, datetime('now','-1 hour'),   50, 'USD');

INSERT INTO portfolio_positions(user_id, instrument_id, quantity, avg_price, currency_code)
VALUES (1, 1, 10, 2800, 'RUB');

INSERT INTO trades(user_id, instrument_id, side, qty, price, currency_code, status, executed_at) VALUES
(1,1,'BUY',  5, 2750,'RUB','EXECUTED', datetime('now','-10 day')),
(1,1,'BUY',  5, 2800,'RUB','EXECUTED', datetime('now','-9 day')),
(1,1,'SELL', 2, 2900,'RUB','EXECUTED', datetime('now','-8 day')),
(1,2,'BUY',  1,   48,'USD','EXECUTED', datetime('now','-7 day')),
(1,1,'BUY',  1, 2850,'RUB','EXECUTED', datetime('now','-6 day')),
(1,1,'SELL', 1, 2950,'RUB','EXECUTED', datetime('now','-5 day')),
(1,1,'BUY',  1, 2890,'RUB','EXECUTED', datetime('now','-4 day')),
(1,2,'SELL', 1,   52,'USD','EXECUTED', datetime('now','-3 day')),
(1,1,'BUY',  1, 2920,'RUB','EXECUTED', datetime('now','-2 day')),
(1,1,'SELL', 1, 2980,'RUB','EXECUTED', datetime('now','-1 day')),
(1,1,'BUY',  1, 3010,'RUB','EXECUTED', datetime('now','-12 hours')),
(1,2,'BUY',  1,   50,'USD','EXECUTED', datetime('now','-6 hours'));


SELECT
  t.trade_id,
  t.executed_at,
  u.full_name,
  i.ticker,
  t.side,
  t.qty,
  t.price,
  t.currency_code,
  t.status
FROM trades t
JOIN users u ON u.user_id = t.user_id
JOIN instruments i ON i.instrument_id = t.instrument_id
ORDER BY t.executed_at DESC
LIMIT 10;


WITH last_price AS (
  SELECT mp.instrument_id, mp.price, mp.currency_code, MAX(mp.as_of_ts) AS as_of_ts
  FROM market_prices mp
  GROUP BY mp.instrument_id
)
SELECT
  u.full_name,
  i.ticker,
  p.quantity,
  p.avg_price,
  lp.price AS last_price,
  p.currency_code,
  ROUND((lp.price - p.avg_price) * p.quantity, 2) AS pl_amount
FROM portfolio_positions p
JOIN users u ON u.user_id = p.user_id
JOIN instruments i ON i.instrument_id = p.instrument_id
JOIN last_price lp ON lp.instrument_id = p.instrument_id;
