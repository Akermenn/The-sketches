PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS product_categories;
DROP TABLE IF EXISTS cafes;

CREATE TABLE cafes (
  cafe_id   INTEGER PRIMARY KEY AUTOINCREMENT,
  name      TEXT NOT NULL,
  address   TEXT,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE product_categories (
  category_id INTEGER PRIMARY KEY AUTOINCREMENT,
  code        TEXT NOT NULL UNIQUE,
  name        TEXT NOT NULL
);

CREATE TABLE products (
  product_id  INTEGER PRIMARY KEY AUTOINCREMENT,
  category_id INTEGER NOT NULL,
  name        TEXT NOT NULL,
  price       REAL NOT NULL,
  is_active   INTEGER NOT NULL DEFAULT 1,
  FOREIGN KEY (category_id) REFERENCES product_categories(category_id)
);

CREATE TABLE orders (
  order_id     INTEGER PRIMARY KEY AUTOINCREMENT,
  cafe_id      INTEGER NOT NULL,
  created_at   TEXT NOT NULL,
  status       TEXT NOT NULL,
  total_amount REAL NOT NULL DEFAULT 0,
  FOREIGN KEY (cafe_id) REFERENCES cafes(cafe_id)
);

CREATE TABLE order_items (
  order_item_id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id      INTEGER NOT NULL,
  product_id    INTEGER NOT NULL,
  qty           INTEGER NOT NULL CHECK (qty > 0),
  unit_price    REAL NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(order_id),
  FOREIGN KEY (product_id) REFERENCES products(product_id)
);

CREATE TABLE payments (
  payment_id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id   INTEGER NOT NULL UNIQUE,
  method     TEXT NOT NULL,
  status     TEXT NOT NULL,
  paid_at    TEXT,
  FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

INSERT INTO cafes(name, address) VALUES
('Сдобная булка — Центр',  'ул. Ленина, 1'),
('Сдобная булка — Вокзал', 'пр. Мира, 10');

INSERT INTO product_categories(code, name) VALUES
('BUN', 'Сдобные булки'),
('COF', 'Кофе');

INSERT INTO products(category_id, name, price) VALUES
((SELECT category_id FROM product_categories WHERE code='BUN'), 'Булочка с корицей', 120),
((SELECT category_id FROM product_categories WHERE code='BUN'), 'Круассан',          150),
((SELECT category_id FROM product_categories WHERE code='COF'), 'Капучино',          180);

INSERT INTO orders(cafe_id, created_at, status, total_amount) VALUES
(1, '2026-01-25 09:10:00', 'готов',     300),
(1, '2026-01-25 12:05:00', 'готовится', 330),
(2, '2026-01-25 18:40:00', 'выдан',     180),
(2, '2026-01-26 10:00:00', 'принят',    120);

INSERT INTO order_items(order_id, product_id, qty, unit_price) VALUES
(1, 1, 1, 120),
(1, 3, 1, 180),
(2, 2, 1, 150),
(2, 3, 1, 180),
(3, 3, 1, 180),
(4, 1, 1, 120);

INSERT INTO payments(order_id, method, status, paid_at) VALUES
(1, 'card', 'paid', '2026-01-25 09:11:00'),
(2, 'card', 'paid', '2026-01-25 12:06:00'),
(3, 'cash', 'paid', '2026-01-25 18:41:00');

WITH
params AS (
  SELECT '2026-01-25' AS day
),
order_totals AS (
  SELECT
      oi.order_id,
      ROUND(SUM(oi.qty * oi.unit_price), 2) AS order_total
  FROM order_items oi
  GROUP BY oi.order_id
),
buns_in_orders AS (
  SELECT
      o.order_id,
      o.created_at,
      c.name AS cafe_name,
      o.status,
      SUM(oi.qty) AS buns_qty,
      ROUND(SUM(oi.qty * oi.unit_price), 2) AS buns_amount,
      GROUP_CONCAT(p.name || ' x' || oi.qty, '; ') AS buns_list
  FROM orders o
  JOIN cafes c               ON c.cafe_id = o.cafe_id
  JOIN order_items oi        ON oi.order_id = o.order_id
  JOIN products p            ON p.product_id = oi.product_id
  JOIN product_categories pc ON pc.category_id = p.category_id
  JOIN params pr             ON 1=1
  WHERE pc.code = 'BUN'
    AND date(o.created_at) = pr.day
  GROUP BY o.order_id, o.created_at, c.name, o.status
)
SELECT
    b.order_id,
    b.created_at,
    b.cafe_name,
    b.status,
    b.buns_list,
    b.buns_qty,
    printf('%.2f', b.buns_amount) AS buns_amount,
    printf('%.2f', t.order_total) AS order_total
FROM buns_in_orders b
JOIN order_totals t ON t.order_id = b.order_id
ORDER BY b.created_at;
