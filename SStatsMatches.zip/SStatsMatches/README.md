# SStatsMatches

Android-приложение для просмотра футбольных матчей с использованием внешнего API.

## Возможности
- отображение матчей на ближайшие 2 дня;
- просмотр команд, лиги и коэффициентов;
- поиск матчей по leagueId и teamId;
- просмотр списка команд и игроков;
- сохранение последних данных и их отображение при отсутствии сети.

## Технологии
- Java
- Android SDK
- Retrofit
- Gson
- Room
- RecyclerView
- Navigation Component

## Запуск проекта
1. Откройте проект в Android Studio.
2. Дождитесь завершения синхронизации Gradle.
3. В файле `local.properties` укажите параметры API:

```
SSTATS_BASE_URL=https://api.sstats.net/
SSTATS_API_KEY=ВАШ_API_KEY
sdk.dir=ПУТЬ_К_ANDROID_SDK
```

4. Запустите приложение на эмуляторе или устройстве.

## API
Используются следующие эндпоинты:
- `games/list`
- `teams/list`
- `players/list`
