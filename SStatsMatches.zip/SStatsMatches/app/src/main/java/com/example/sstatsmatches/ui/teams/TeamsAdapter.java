package com.example.sstatsmatches.ui.teams;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.sstatsmatches.data.model.TeamItem;
import com.example.sstatsmatches.databinding.ItemTeamBinding;

import java.util.ArrayList;
import java.util.List;

public class TeamsAdapter extends RecyclerView.Adapter<TeamsAdapter.Holder> {

    public interface OnTeamClick {
        void onClick(TeamItem team);
    }

    private final List<TeamItem> items = new ArrayList<>();
    private final OnTeamClick click;

    public TeamsAdapter(OnTeamClick click) {
        this.click = click;
    }

    public void setItems(List<TeamItem> newItems) {
        items.clear();
        if (newItems != null) items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemTeamBinding b = ItemTeamBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new Holder(b);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        TeamItem t = items.get(position);

        h.b.teamName.setText(t.name == null ? "" : t.name);
        Glide.with(h.itemView).load(t.logo).into(h.b.teamLogo);

        h.itemView.setOnClickListener(v -> {
            if (click != null) click.onClick(t);
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        final ItemTeamBinding b;

        Holder(ItemTeamBinding b) {
            super(b.getRoot());
            this.b = b;
        }
    }
}
