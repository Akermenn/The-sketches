package com.example.sstatsmatches.ui.players;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.sstatsmatches.data.model.PlayerItem;
import com.example.sstatsmatches.databinding.ItemPlayerBinding;

import java.util.ArrayList;
import java.util.List;

public class PlayersAdapter extends RecyclerView.Adapter<PlayersAdapter.Holder> {

    private final List<PlayerItem> items = new ArrayList<>();

    public void setItems(List<PlayerItem> newItems) {
        items.clear();
        if (newItems != null) items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemPlayerBinding b = ItemPlayerBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new Holder(b);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        PlayerItem p = items.get(position);

        h.b.playerName.setText(p.name == null ? "" : p.name);
        h.b.playerPos.setText(p.position == null ? "" : p.position);
        Glide.with(h.itemView).load(p.photo).into(h.b.playerPhoto);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        final ItemPlayerBinding b;

        Holder(ItemPlayerBinding b) {
            super(b.getRoot());
            this.b = b;
        }
    }
}
