package com.example.sstatsmatches.data.local;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface MatchDao {

    @Query("SELECT * FROM matches ORDER BY savedAt DESC LIMIT 10")
    List<MatchEntity> lastTen();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void upsertAll(List<MatchEntity> items);

    @Query("DELETE FROM matches WHERE id NOT IN (SELECT id FROM matches ORDER BY savedAt DESC LIMIT 10)")
    void trimToTen();
}
