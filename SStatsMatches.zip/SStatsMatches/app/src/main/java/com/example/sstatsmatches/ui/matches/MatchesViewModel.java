package com.example.sstatsmatches.ui.matches;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import com.example.sstatsmatches.data.model.MatchItem;
import com.example.sstatsmatches.data.repository.MatchesRepository;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MatchesViewModel extends AndroidViewModel {

    public final MutableLiveData<State> state = new MutableLiveData<>();

    private final MatchesRepository repo;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    public MatchesViewModel(@NonNull Application application) {
        super(application);
        repo = new MatchesRepository(application);
    }

    public void load(Integer leagueId, Integer teamId) {
        state.setValue(State.loading());

        io.submit(() -> {
            MatchesRepository.Result<List<MatchItem>> res = repo.loadNextTwoDays(leagueId, teamId);
            if (!res.ok) {
                state.postValue(State.error(res.message));
                return;
            }
            state.postValue(State.data(res.data, res.fromCache, res.message));
        });
    }

    public static class State {
        public final boolean loading;
        public final String error;
        public final List<MatchItem> items;
        public final boolean fromCache;
        public final String cacheMessage;

        private State(boolean loading, String error, List<MatchItem> items, boolean fromCache, String cacheMessage) {
            this.loading = loading;
            this.error = error;
            this.items = items;
            this.fromCache = fromCache;
            this.cacheMessage = cacheMessage;
        }

        public static State loading() {
            return new State(true, "", null, false, "");
        }

        public static State error(String msg) {
            return new State(false, msg == null ? "" : msg, null, false, "");
        }

        public static State data(List<MatchItem> items, boolean fromCache, String cacheMsg) {
            return new State(false, "", items, fromCache, cacheMsg == null ? "" : cacheMsg);
        }
    }
}
