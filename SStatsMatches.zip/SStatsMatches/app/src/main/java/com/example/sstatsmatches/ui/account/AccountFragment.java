package com.example.sstatsmatches.ui.account;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.sstatsmatches.data.repository.AuthRepository;
import com.example.sstatsmatches.databinding.FragmentAccountBinding;
import com.google.android.material.snackbar.Snackbar;

public class AccountFragment extends Fragment {

    private FragmentAccountBinding binding;
    private AuthRepository auth;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentAccountBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        auth = new AuthRepository(requireContext());
        render();

        binding.loginButton.setOnClickListener(v -> {
            String login = binding.loginInput.getText() == null ? "" : binding.loginInput.getText().toString();
            String pass = binding.passwordInput.getText() == null ? "" : binding.passwordInput.getText().toString();

            auth.login(login, pass);
            Snackbar.make(binding.getRoot(), "Logged in", Snackbar.LENGTH_SHORT).show();
            render();
        });

        binding.logoutButton.setOnClickListener(v -> {
            auth.logout();
            Snackbar.make(binding.getRoot(), "Logged out", Snackbar.LENGTH_SHORT).show();
            render();
        });
    }

    private void render() {
        boolean logged = auth.isLoggedIn();
        binding.statusText.setText(logged ? ("Logged as: " + auth.currentLogin()) : "Not logged in");

        binding.loginInput.setEnabled(!logged);
        binding.passwordInput.setEnabled(!logged);

        binding.loginButton.setVisibility(logged ? View.GONE : View.VISIBLE);
        binding.logoutButton.setVisibility(logged ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
