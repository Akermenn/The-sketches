package com.example.sstatsmatches.data.repository;

import android.content.Context;
import android.content.SharedPreferences;

public class AuthRepository {

    private final SharedPreferences prefs;

    public AuthRepository(Context context) {
        this.prefs = context.getSharedPreferences("auth", Context.MODE_PRIVATE);
    }

    public boolean isLoggedIn() {
        return prefs.getBoolean("logged", false);
    }

    public void login(String login, String password) {
        prefs.edit()
                .putBoolean("logged", true)
                .putString("login", login == null ? "" : login.trim())
                .apply();
    }

    public void logout() {
        prefs.edit().putBoolean("logged", false).apply();
    }

    public String currentLogin() {
        return prefs.getString("login", "");
    }
}
