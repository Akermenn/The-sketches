package com.example.sstatsmatches.network;

import com.example.sstatsmatches.data.model.MatchItem;
import com.example.sstatsmatches.data.model.PlayerItem;
import com.example.sstatsmatches.data.model.TeamItem;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;

public final class SStatsParser {

    private static final Gson gson = new Gson();

    private SStatsParser() {
    }

    public static List<MatchItem> parseMatches(ResponseBody body) throws Exception {
        String raw = body.string();
        JsonElement root = gson.fromJson(raw, JsonElement.class);

        JsonArray arr = findArray(root, "games", "matches", "data", "result");
        if (arr == null && root != null && root.isJsonArray()) arr = root.getAsJsonArray();

        List<MatchItem> out = new ArrayList<>();
        if (arr == null) return out;

        for (JsonElement el : arr) {
            if (!el.isJsonObject()) continue;
            JsonObject o = el.getAsJsonObject();

            MatchItem item = new MatchItem();
            item.id = optInt(o, "id", "gameid", "matchid");
            item.date = optStr(o, "date", "gamedate");
            item.time = optStr(o, "time", "gametime");

            JsonObject home = optObj(o, "home", "team_home", "hometeam");
            JsonObject away = optObj(o, "away", "team_away", "awayteam");
            item.homeName = optStr(home, "name", "teamname");
            item.awayName = optStr(away, "name", "teamname");
            item.homeLogo = optStr(home, "logo", "image", "img");
            item.awayLogo = optStr(away, "logo", "image", "img");

            JsonObject league = optObj(o, "league");
            item.leagueName = optStr(league, "name", "leaguename");
            item.leagueLogo = optStr(league, "logo", "image", "img");

            JsonObject country = optObj(o, "country");
            item.countryName = optStr(country, "name", "countryname");
            item.countryFlag = optStr(country, "flag", "image", "img");

            JsonObject odds = optObj(o, "odds", "coef", "coefficients");
            item.oddsHome = optDbl(odds, "home", "1");
            item.oddsDraw = optDbl(odds, "draw", "x");
            item.oddsAway = optDbl(odds, "away", "2");

            out.add(item);
        }

        return out;
    }

    public static List<TeamItem> parseTeams(ResponseBody body) throws Exception {
        String raw = body.string();
        JsonElement root = gson.fromJson(raw, JsonElement.class);

        JsonArray arr = findArray(root, "teams", "data", "result");
        if (arr == null && root != null && root.isJsonArray()) arr = root.getAsJsonArray();

        List<TeamItem> out = new ArrayList<>();
        if (arr == null) return out;

        for (JsonElement el : arr) {
            if (!el.isJsonObject()) continue;
            JsonObject o = el.getAsJsonObject();

            TeamItem t = new TeamItem();
            t.id = optInt(o, "id", "teamid");
            t.name = optStr(o, "name", "teamname");
            t.logo = optStr(o, "logo", "image", "img");
            out.add(t);
        }

        return out;
    }

    public static List<PlayerItem> parsePlayers(ResponseBody body) throws Exception {
        String raw = body.string();
        JsonElement root = gson.fromJson(raw, JsonElement.class);

        JsonArray arr = findArray(root, "players", "data", "result");
        if (arr == null && root != null && root.isJsonArray()) arr = root.getAsJsonArray();

        List<PlayerItem> out = new ArrayList<>();
        if (arr == null) return out;

        for (JsonElement el : arr) {
            if (!el.isJsonObject()) continue;
            JsonObject o = el.getAsJsonObject();

            PlayerItem p = new PlayerItem();
            p.id = optInt(o, "id", "playerid");
            p.name = optStr(o, "name", "playername");
            p.position = optStr(o, "position", "role");
            p.photo = optStr(o, "photo", "image", "img");
            out.add(p);
        }

        return out;
    }

    private static JsonArray findArray(JsonElement root, String... keys) {
        if (root == null) return null;
        if (root.isJsonObject()) {
            JsonObject obj = root.getAsJsonObject();
            for (String k : keys) {
                if (obj.has(k) && obj.get(k).isJsonArray()) {
                    return obj.getAsJsonArray(k);
                }
            }
        }
        return null;
    }

    private static JsonObject optObj(JsonObject o, String... keys) {
        if (o == null) return null;
        for (String k : keys) {
            if (o.has(k) && o.get(k).isJsonObject()) return o.getAsJsonObject(k);
        }
        return null;
    }

    private static String optStr(JsonObject o, String... keys) {
        if (o == null) return "";
        for (String k : keys) {
            if (o.has(k) && !o.get(k).isJsonNull()) {
                try {
                    return o.get(k).getAsString();
                } catch (Exception ignored) {
                }
            }
        }
        return "";
    }

    private static Integer optInt(JsonObject o, String... keys) {
        if (o == null) return null;
        for (String k : keys) {
            if (o.has(k) && !o.get(k).isJsonNull()) {
                try {
                    return o.get(k).getAsInt();
                } catch (Exception ignored) {
                }
            }
        }
        return null;
    }

    private static Double optDbl(JsonObject o, String... keys) {
        if (o == null) return null;
        for (String k : keys) {
            if (o.has(k) && !o.get(k).isJsonNull()) {
                try {
                    return o.get(k).getAsDouble();
                } catch (Exception ignored) {
                }
            }
        }
        return null;
    }
}
