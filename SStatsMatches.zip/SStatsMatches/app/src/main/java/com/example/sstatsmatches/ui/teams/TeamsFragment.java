package com.example.sstatsmatches.ui.teams;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.sstatsmatches.R;
import com.example.sstatsmatches.data.model.TeamItem;
import com.example.sstatsmatches.data.repository.TeamsRepository;
import com.example.sstatsmatches.databinding.FragmentTeamsBinding;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TeamsFragment extends Fragment {

    private FragmentTeamsBinding binding;
    private TeamsAdapter adapter;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentTeamsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        adapter = new TeamsAdapter(team -> {
            Bundle args = new Bundle();
            if (team.id != null) args.putInt("teamId", team.id);
            args.putString("teamName", team.name == null ? "" : team.name);
            NavHostFragment.findNavController(this).navigate(R.id.playersFragment, args);
        });

        binding.teamsList.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.teamsList.setAdapter(adapter);

        Integer leagueId = null;
        if (getArguments() != null && getArguments().containsKey("leagueId")) {
            leagueId = getArguments().getInt("leagueId");
        }

        load(leagueId);
    }

    private void load(Integer leagueId) {
        binding.progress.setVisibility(View.VISIBLE);

        io.submit(() -> {
            try {
                TeamsRepository repo = new TeamsRepository();
                List<TeamItem> items = repo.loadTeams(leagueId);

                requireActivity().runOnUiThread(() -> {
                    binding.progress.setVisibility(View.GONE);
                    adapter.setItems(items);
                    if (items == null || items.isEmpty()) {
                        Snackbar.make(binding.getRoot(), "No teams found", Snackbar.LENGTH_LONG).show();
                    }
                });
            } catch (Exception e) {
                requireActivity().runOnUiThread(() -> {
                    binding.progress.setVisibility(View.GONE);
                    Snackbar.make(binding.getRoot(), "Network error", Snackbar.LENGTH_LONG).show();
                });
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
