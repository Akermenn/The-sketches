package com.example.sstatsmatches.data.local;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "matches")
public class MatchEntity {

    @PrimaryKey
    public int id;

    public String date;
    public String time;

    public String homeName;
    public String awayName;

    public String homeLogo;
    public String awayLogo;

    public String leagueName;
    public String leagueLogo;

    public String countryName;
    public String countryFlag;

    public Double oddsHome;
    public Double oddsDraw;
    public Double oddsAway;

    public long savedAt;
}
