package com.example.sstatsmatches.data.model;

public class TeamItem {
    public Integer id;
    public String name;
    public String logo;
}
