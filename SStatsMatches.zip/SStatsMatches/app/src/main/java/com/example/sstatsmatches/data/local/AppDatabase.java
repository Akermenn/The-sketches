package com.example.sstatsmatches.data.local;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {MatchEntity.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {

    private static AppDatabase instance;

    public abstract MatchDao matchDao();

    public static AppDatabase get(Context context) {
        if (instance != null) return instance;

        synchronized (AppDatabase.class) {
            if (instance == null) {
                instance = Room.databaseBuilder(
                                context.getApplicationContext(),
                                AppDatabase.class,
                                "sstats.db"
                        )
                        .fallbackToDestructiveMigration()
                        .build();
            }
        }
        return instance;
    }
}
