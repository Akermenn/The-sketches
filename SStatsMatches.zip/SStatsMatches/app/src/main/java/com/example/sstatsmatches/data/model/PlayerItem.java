package com.example.sstatsmatches.data.model;

public class PlayerItem {
    public Integer id;
    public String name;
    public String position;
    public String photo;
}
