package com.example.sstatsmatches.ui.matches;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.sstatsmatches.databinding.FragmentMatchesBinding;
import com.google.android.material.snackbar.Snackbar;

public class MatchesFragment extends Fragment {

    private FragmentMatchesBinding binding;
    private MatchesViewModel vm;
    private MatchesAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentMatchesBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        vm = new ViewModelProvider(this).get(MatchesViewModel.class);

        adapter = new MatchesAdapter();
        binding.matchesList.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.matchesList.setAdapter(adapter);

        binding.refreshButton.setOnClickListener(v -> vm.load(readLeagueId(), readTeamId()));

        vm.state.observe(getViewLifecycleOwner(), st -> {
            binding.progress.setVisibility(st.loading ? View.VISIBLE : View.GONE);

            if (st.error != null && !st.error.isEmpty()) {
                Snackbar.make(binding.getRoot(), "Network error: " + st.error, Snackbar.LENGTH_LONG).show();
                return;
            }

            if (st.items != null) {
                adapter.setItems(st.items);
            }

            if (st.fromCache) {
                String msg = "Showing cached data";
                if (st.cacheMessage != null && !st.cacheMessage.isEmpty()) {
                    msg = msg + " (" + st.cacheMessage + ")";
                }
                Snackbar.make(binding.getRoot(), msg, Snackbar.LENGTH_LONG).show();
            }
        });

        vm.load(readLeagueId(), readTeamId());
    }

    private Integer readLeagueId() {
        if (getArguments() == null) return null;
        if (!getArguments().containsKey("leagueId")) return null;
        return getArguments().getInt("leagueId");
    }

    private Integer readTeamId() {
        if (getArguments() == null) return null;
        if (!getArguments().containsKey("teamId")) return null;
        return getArguments().getInt("teamId");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
