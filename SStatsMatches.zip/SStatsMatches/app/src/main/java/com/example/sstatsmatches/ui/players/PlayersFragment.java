package com.example.sstatsmatches.ui.players;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.sstatsmatches.data.model.PlayerItem;
import com.example.sstatsmatches.data.repository.TeamsRepository;
import com.example.sstatsmatches.databinding.FragmentPlayersBinding;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PlayersFragment extends Fragment {

    private FragmentPlayersBinding binding;
    private PlayersAdapter adapter;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentPlayersBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        adapter = new PlayersAdapter();
        binding.playersList.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.playersList.setAdapter(adapter);

        int teamId = 0;
        String teamName = "";
        if (getArguments() != null) {
            teamId = getArguments().getInt("teamId", 0);
            teamName = getArguments().getString("teamName", "");
        }

        binding.title.setText(teamName == null || teamName.isEmpty() ? "Players" : teamName);

        if (teamId == 0) {
            Snackbar.make(binding.getRoot(), "TeamId missing", Snackbar.LENGTH_LONG).show();
            return;
        }

        load(teamId);
    }

    private void load(int teamId) {
        binding.progress.setVisibility(View.VISIBLE);

        io.submit(() -> {
            try {
                TeamsRepository repo = new TeamsRepository();
                List<PlayerItem> items = repo.loadPlayers(teamId);

                requireActivity().runOnUiThread(() -> {
                    binding.progress.setVisibility(View.GONE);
                    adapter.setItems(items);
                    if (items == null || items.isEmpty()) {
                        Snackbar.make(binding.getRoot(), "No players found", Snackbar.LENGTH_LONG).show();
                    }
                });
            } catch (Exception e) {
                requireActivity().runOnUiThread(() -> {
                    binding.progress.setVisibility(View.GONE);
                    Snackbar.make(binding.getRoot(), "Network error", Snackbar.LENGTH_LONG).show();
                });
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
