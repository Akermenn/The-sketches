package com.example.sstatsmatches.ui.search;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.sstatsmatches.R;
import com.example.sstatsmatches.databinding.FragmentSearchBinding;
import com.google.android.material.snackbar.Snackbar;

public class SearchFragment extends Fragment {

    private FragmentSearchBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentSearchBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        binding.openTeams.setOnClickListener(v -> {
            String leagueStr = binding.leagueIdInput.getText() == null ? "" : binding.leagueIdInput.getText().toString().trim();

            Bundle args = new Bundle();
            if (!TextUtils.isEmpty(leagueStr)) {
                try {
                    args.putInt("leagueId", Integer.parseInt(leagueStr));
                } catch (Exception e) {
                    Snackbar.make(binding.getRoot(), "LeagueId must be a number", Snackbar.LENGTH_LONG).show();
                    return;
                }
            }
            NavHostFragment.findNavController(this).navigate(R.id.teamsFragment, args);
        });

        binding.applyMatchesFilter.setOnClickListener(v -> {
            String leagueStr = binding.leagueIdInput.getText() == null ? "" : binding.leagueIdInput.getText().toString().trim();
            String teamStr = binding.teamIdInput.getText() == null ? "" : binding.teamIdInput.getText().toString().trim();

            Bundle args = new Bundle();
            if (!TextUtils.isEmpty(leagueStr)) {
                try {
                    args.putInt("leagueId", Integer.parseInt(leagueStr));
                } catch (Exception e) {
                    Snackbar.make(binding.getRoot(), "LeagueId must be a number", Snackbar.LENGTH_LONG).show();
                    return;
                }
            }
            if (!TextUtils.isEmpty(teamStr)) {
                try {
                    args.putInt("teamId", Integer.parseInt(teamStr));
                } catch (Exception e) {
                    Snackbar.make(binding.getRoot(), "TeamId must be a number", Snackbar.LENGTH_LONG).show();
                    return;
                }
            }

            NavHostFragment.findNavController(this).navigate(R.id.matchesFragment, args);
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
