package com.example.sstatsmatches.network;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface SStatsApi {

    @GET("games/list")
    Call<ResponseBody> games(
            @Query("from") String from,
            @Query("to") String to,
            @Query("leagueid") Integer leagueId,
            @Query("teamid") Integer teamId,
            @Query("order") Integer order,
            @Query("apikey") String apiKey
    );

    @GET("teams/list")
    Call<ResponseBody> teams(
            @Query("leagueid") Integer leagueId,
            @Query("apikey") String apiKey
    );

    @GET("players/list")
    Call<ResponseBody> players(
            @Query("teamid") Integer teamId,
            @Query("apikey") String apiKey
    );
}
