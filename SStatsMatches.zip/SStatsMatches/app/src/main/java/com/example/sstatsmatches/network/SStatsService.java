package com.example.sstatsmatches.network;

import com.example.sstatsmatches.BuildConfig;

import retrofit2.Retrofit;

public final class SStatsService {

    private static SStatsApi api;

    private SStatsService() {
    }

    public static SStatsApi api() {
        if (api != null) return api;

        Retrofit retrofit = ApiClient.build(BuildConfig.SSTATS_BASE_URL);
        api = retrofit.create(SStatsApi.class);
        return api;
    }
}
