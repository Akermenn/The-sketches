package com.example.sstatsmatches.data.repository;

import android.content.Context;

import com.example.sstatsmatches.BuildConfig;
import com.example.sstatsmatches.data.local.AppDatabase;
import com.example.sstatsmatches.data.local.MatchEntity;
import com.example.sstatsmatches.data.model.MatchItem;
import com.example.sstatsmatches.network.SStatsParser;
import com.example.sstatsmatches.network.SStatsService;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

public class MatchesRepository {

    private final AppDatabase db;

    public MatchesRepository(Context context) {
        this.db = AppDatabase.get(context);
    }

    public Result<List<MatchItem>> loadNextTwoDays(Integer leagueId, Integer teamId) {
        try {
            LocalDate now = LocalDate.now();
            String from = now.toString();
            String to = now.plusDays(2).toString();

            Call<ResponseBody> call = SStatsService.api().games(
                    from, to, leagueId, teamId, 1, BuildConfig.SSTATS_API_KEY
            );

            Response<ResponseBody> resp = call.execute();
            if (!resp.isSuccessful() || resp.body() == null) {
                return fromCache("Network error");
            }

            List<MatchItem> items = SStatsParser.parseMatches(resp.body());
            saveCache(items);
            return Result.ok(items, false);
        } catch (Exception e) {
            return fromCache(e.getMessage() == null ? "Network error" : e.getMessage());
        }
    }

    private Result<List<MatchItem>> fromCache(String reason) {
        try {
            List<MatchEntity> cached = db.matchDao().lastTen();
            List<MatchItem> out = new ArrayList<>();
            for (MatchEntity m : cached) {
                MatchItem it = new MatchItem();
                it.id = m.id;
                it.date = m.date;
                it.time = m.time;
                it.homeName = m.homeName;
                it.awayName = m.awayName;
                it.homeLogo = m.homeLogo;
                it.awayLogo = m.awayLogo;
                it.leagueName = m.leagueName;
                it.leagueLogo = m.leagueLogo;
                it.countryName = m.countryName;
                it.countryFlag = m.countryFlag;
                it.oddsHome = m.oddsHome;
                it.oddsDraw = m.oddsDraw;
                it.oddsAway = m.oddsAway;
                out.add(it);
            }
            return Result.ok(out, true, reason);
        } catch (Exception e) {
            return Result.fail(reason);
        }
    }

    private void saveCache(List<MatchItem> items) {
        if (items == null) return;

        long now = System.currentTimeMillis();
        List<MatchEntity> entities = new ArrayList<>();

        for (MatchItem it : items) {
            if (it == null || it.id == null) continue;

            MatchEntity e = new MatchEntity();
            e.id = it.id;
            e.date = it.date;
            e.time = it.time;
            e.homeName = safe(it.homeName);
            e.awayName = safe(it.awayName);
            e.homeLogo = safe(it.homeLogo);
            e.awayLogo = safe(it.awayLogo);
            e.leagueName = safe(it.leagueName);
            e.leagueLogo = safe(it.leagueLogo);
            e.countryName = safe(it.countryName);
            e.countryFlag = safe(it.countryFlag);
            e.oddsHome = it.oddsHome;
            e.oddsDraw = it.oddsDraw;
            e.oddsAway = it.oddsAway;
            e.savedAt = now;

            entities.add(e);
        }

        if (entities.isEmpty()) return;

        db.matchDao().upsertAll(entities);
        db.matchDao().trimToTen();
    }

    private String safe(String s) {
        return s == null ? "" : s;
    }

    public static class Result<T> {
        public final boolean ok;
        public final boolean fromCache;
        public final String message;
        public final T data;

        private Result(boolean ok, boolean fromCache, String message, T data) {
            this.ok = ok;
            this.fromCache = fromCache;
            this.message = message;
            this.data = data;
        }

        public static <T> Result<T> ok(T data, boolean fromCache) {
            return new Result<>(true, fromCache, "", data);
        }

        public static <T> Result<T> ok(T data, boolean fromCache, String msg) {
            return new Result<>(true, fromCache, msg == null ? "" : msg, data);
        }

        public static <T> Result<T> fail(String msg) {
            return new Result<>(false, false, msg == null ? "" : msg, null);
        }
    }
}
