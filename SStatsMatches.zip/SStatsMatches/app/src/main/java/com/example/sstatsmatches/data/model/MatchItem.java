package com.example.sstatsmatches.data.model;

public class MatchItem {
    public Integer id;

    public String date;
    public String time;

    public String homeName;
    public String awayName;

    public String homeLogo;
    public String awayLogo;

    public String leagueName;
    public String leagueLogo;

    public String countryName;
    public String countryFlag;

    public Double oddsHome;
    public Double oddsDraw;
    public Double oddsAway;
}
