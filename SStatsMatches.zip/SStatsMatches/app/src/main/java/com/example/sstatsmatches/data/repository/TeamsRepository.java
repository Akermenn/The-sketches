package com.example.sstatsmatches.data.repository;

import com.example.sstatsmatches.BuildConfig;
import com.example.sstatsmatches.data.model.PlayerItem;
import com.example.sstatsmatches.data.model.TeamItem;
import com.example.sstatsmatches.network.SStatsParser;
import com.example.sstatsmatches.network.SStatsService;

import java.util.Collections;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

public class TeamsRepository {

    public List<TeamItem> loadTeams(Integer leagueId) throws Exception {
        Call<ResponseBody> call = SStatsService.api().teams(leagueId, BuildConfig.SSTATS_API_KEY);
        Response<ResponseBody> resp = call.execute();
        if (!resp.isSuccessful() || resp.body() == null) return Collections.emptyList();
        return SStatsParser.parseTeams(resp.body());
    }

    public List<PlayerItem> loadPlayers(Integer teamId) throws Exception {
        Call<ResponseBody> call = SStatsService.api().players(teamId, BuildConfig.SSTATS_API_KEY);
        Response<ResponseBody> resp = call.execute();
        if (!resp.isSuccessful() || resp.body() == null) return Collections.emptyList();
        return SStatsParser.parsePlayers(resp.body());
    }
}
