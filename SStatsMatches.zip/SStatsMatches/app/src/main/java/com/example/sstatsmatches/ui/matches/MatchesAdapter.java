package com.example.sstatsmatches.ui.matches;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.sstatsmatches.data.model.MatchItem;
import com.example.sstatsmatches.databinding.ItemMatchBinding;

import java.util.ArrayList;
import java.util.List;

public class MatchesAdapter extends RecyclerView.Adapter<MatchesAdapter.Holder> {

    private final List<MatchItem> items = new ArrayList<>();

    public void setItems(List<MatchItem> newItems) {
        items.clear();
        if (newItems != null) items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemMatchBinding binding = ItemMatchBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false
        );
        return new Holder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        MatchItem it = items.get(position);

        String d = it.date == null ? "" : it.date;
        String t = it.time == null ? "" : it.time;
        h.b.time.setText((d + " " + t).trim());

        h.b.homeName.setText(it.homeName == null ? "" : it.homeName);
        h.b.awayName.setText(it.awayName == null ? "" : it.awayName);

        String league = it.leagueName == null ? "" : it.leagueName;
        String country = it.countryName == null ? "" : it.countryName;
        String line = league;
        if (!country.isEmpty()) line = line.isEmpty() ? country : (league + " • " + country);
        h.b.leagueCountry.setText(line);

        h.b.oddHome.setText(formatOdd(it.oddsHome));
        h.b.oddDraw.setText(formatOdd(it.oddsDraw));
        h.b.oddAway.setText(formatOdd(it.oddsAway));

        Glide.with(h.itemView).load(it.homeLogo).into(h.b.homeLogo);
        Glide.with(h.itemView).load(it.awayLogo).into(h.b.awayLogo);
        Glide.with(h.itemView).load(it.leagueLogo).into(h.b.leagueLogo);
        Glide.with(h.itemView).load(it.countryFlag).into(h.b.countryFlag);
    }

    private String formatOdd(Double d) {
        if (d == null) return "-";
        String s = String.valueOf(d);
        if (s.endsWith(".0")) s = s.substring(0, s.length() - 2);
        return s;
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        final ItemMatchBinding b;

        Holder(ItemMatchBinding b) {
            super(b.getRoot());
            this.b = b;
        }
    }
}
