from fractions import Fraction
from itertools import combinations

def solve():
    # Длины из условия
    L1, L2, L3, L4, L5, L6, L7, L8 = map(Fraction, [1, 3, 2, 1, 1, 2, 1, 4])

    # Гири: номер -> масса
    w = {1: 100, 2: 75, 3: 50, 4: 40, 5: 15, 6: 10, 7: 10}
    total = sum(w.values())

    # --- Находим целевые массы чаш A..E через уравнения моментов ---
    # M2 = M1 * L3/L4
    # M4 = M5 * L8/L7
    # M3 = (M4+M5) * L5/L6
    # (M1+M2)*L1 = (M3+M4+M5)*L2

    coeff_left = (1 + L3 / L4) * L1

    # Правая часть при M5 = 1
    M5_1 = Fraction(1, 1)
    M4_1 = M5_1 * L8 / L7
    M3_1 = (M4_1 + M5_1) * L5 / L6
    rhs_1 = (M3_1 + M4_1 + M5_1) * L2

    # M1 = M1_per_M5 * M5
    M1_per_M5 = rhs_1 / coeff_left

    # Сумма масс при M5 = 1
    M1_1 = M1_per_M5
    M2_1 = M1_1 * L3 / L4
    total_per_M5 = M1_1 + M2_1 + M3_1 + M4_1 + M5_1

    # Находим M5 по сумме всех гирь
    M5 = Fraction(total, 1) / total_per_M5
    if M5.denominator != 1:
        raise ValueError("Не удалось получить целочисленные массы чаш (проверьте входные данные).")

    M5 = int(M5)
    M4 = int(Fraction(M5, 1) * L8 / L7)
    M3 = int(Fraction(M4 + M5, 1) * L5 / L6)
    M1 = int(M1_per_M5 * M5)
    M2 = int(Fraction(M1, 1) * L3 / L4)

    targets = {"A": M1, "B": M2, "C": M4, "D": M5, "E": M3}

    # --- Раскладка гирь ---
    # Условие: гиря №7 обязательно в чаше D
    assign = {"D": [7]}
    remaining = [i for i in w.keys() if i != 7]
    cups = ["A", "B", "C", "E"]

    def backtrack(idx, rem, cur):
        if idx == len(cups):
            if rem:
                return None
            # Ровно 2 чаши с двумя гирями
            twos = sum(1 for c in ["A", "B", "C", "D", "E"] if len(cur.get(c, [])) == 2)
            if twos != 2:
                return None
            return cur

        cup = cups[idx]
        target = targets[cup]

        for r in (1, 2):
            for comb in combinations(rem, r):
                if sum(w[i] for i in comb) == target:
                    nxt = dict(cur)
                    nxt[cup] = list(comb)
                    nxt_rem = [x for x in rem if x not in comb]
                    res = backtrack(idx + 1, nxt_rem, nxt)
                    if res is not None:
                        return res
        return None

    sol = backtrack(0, remaining, assign)
    if sol is None:
        print("Решение не найдено.")
        return

    print("Целевые суммы чаш:", targets)
    print("Ответ (чаша - номер гири):")
    for cup in ["A", "B", "C", "D", "E"]:
        for num in sol.get(cup, []):
            print(f"{cup} - {num}")

if __name__ == "__main__":
    solve()
